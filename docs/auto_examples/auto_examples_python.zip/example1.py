"""
Example 1
=========

some information 1 appears onmouse over
"""

import numpy as np
import matplotlib.pyplot as plt

xs = np.linspace(0,10,100)
plt.plot(xs, np.sin(xs))
plt.show()
